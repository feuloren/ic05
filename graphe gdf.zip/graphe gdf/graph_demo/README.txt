Démo pour une présentation à **parisjs**, Octobre 2012
Pour lancer la démo:
  - Récupérez le fichier GDF de vos données Facebook grâce à l'application
    Netvizz: https://apps.facebook.com/netvizz/
  - Remplacez "graph.gdf" par ce fichier
  - Pour permettre le chargement de votre fichier, vous devez lancer la démo
    sur un serveur (le plus simple: "python -m SimpleHTTPServer 8888")

Les slides sont disponibles à l'adresse:
  http://rvl.io/jacomyal/parisjs-octobre-2012
Le code source de la démo est disponible à l'adresse:
  http://github.com/jacomyal/parisjs-oct2012-demo